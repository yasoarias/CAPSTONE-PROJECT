const validatePackage = (req, res, next) => {
  const { name, price, category, guestLimit } = req.body;
  
  if (!name || !price || !category || !guestLimit) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  
  if (isNaN(guestLimit) || guestLimit < 1) {
    return res.status(400).json({ error: 'Guest limit must be a positive number' });
  }
  
  // Validate category
  const validCategories = ['wedding', 'debut', 'christening', 'kiddie-party'];
  if (!validCategories.includes(category.toLowerCase())) {
    return res.status(400).json({ error: 'Invalid package category' });
  }
  
  next();
};

module.exports = validatePackage; 