const db = require('../../config/dbConfig.js');

exports.contactUs = async (req, res) => {
    try {
        const { name, email, phone, message  } = req.body;
    
        const query = "INSERT INTO `contact_us`(`name`, `email`, `phone`, `message`) VALUES (?,?,?,?)";
        db.query( query, [name, email, phone, message], 
            (err, result) => {
                if (err) {
                    console.error("Error inserting data into MySQL:", err);
                    if (err.code === "ER_DUP_ENTRY") {
                    res
                        .status(400)
                        .json({ success: false, message: "Email already exists" });
                    } else {
                    res.status(500).json({ success: false, message: "Database error" });
                    }
                    return;
                }
                res.json({ success: true, message: "Contact Successfully Sent" });
            }
        );
      } catch (error) {
        res.status(500).json({
          success: false,
          message: "An error occurred during registration",
        });
      }

};