// backend/controllers/userController.js
const bcrypt = require("bcrypt");
const db = require("../config/dbConfig.js");

exports.getUserProfile = async (req, res) => {
  const userId = req.user.id;
  console.log("Fetching profile for user ID:", userId);

  const query =
    "SELECT id, role, fullName, email, contactNo, termsAccepted, created_at, profilePicture FROM users WHERE id = ?";
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error("Error fetching user profile:", err);
      res.status(500).json({ message: "Error fetching user profile" });
      return;
    }

    if (results.length === 0) {
      console.log("No user found with ID:", userId);
      res.status(404).json({ message: "User not found" });
      return;
    }

    const user = results[0];
    console.log("Fetched user data:", user);
    res.json(user);
  });
};

exports.adminUsers = async (req, res) => {
  const query = "SELECT id, fullName, email, role FROM users";
  db.query(query, (err, results) => {
    if (err) {
      res.status(500).json({ message: "Error on the server." });
      return;
    }
    res.status(200).json(results);
  });
};
