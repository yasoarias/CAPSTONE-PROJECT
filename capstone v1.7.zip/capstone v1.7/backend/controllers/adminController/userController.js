const db = require('../../config/dbConfig.js');

exports.getAllUsers = async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
  
    const query =
      "SELECT id, fullName, email, created_at FROM users LIMIT ? OFFSET ?";
    db.query(query, [limit, offset], (err, results) => {
      if (err) {
        console.error("Error fetching users:", err);
        return res.status(500).json({ message: "Internal Server Error" });
      }
  
      // Fetch total count for pagination
      db.query(
        "SELECT COUNT(*) as total FROM users",
        (countErr, countResults) => {
          if (countErr) {
            console.error("Error fetching user count:", countErr);
            return res.status(500).json({ message: "Internal Server Error" });
          }
  
          res.json({
            users: results,
            total: countResults[0].total,
            totalPages: Math.ceil(countResults[0].total / limit),
            page: page,
          });
        }
      );
    });
  }
  