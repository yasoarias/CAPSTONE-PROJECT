const db = require('../../config/dbConfig.js');

exports.addProduct = async (req, res) => {
    const { name, description, price, category } = req.body;
    const imagePath = req.file ? `/uploads/${req.file.filename}` : null;

    console.log("Received product data:", {
        name,
        description,
        price,
        category,
        imagePath,
    });

    const query =
        "INSERT INTO products (name, description, price, category, image_path) VALUES (?, ?, ?, ?, ?)";
    db.query(
        query,
        [name, description, price, category, imagePath],
        (err, result) => {
            if (err) {
                console.error("Error adding product:", err);
                res
                    .status(500)
                    .json({ success: false, message: "Error adding product" });
                return;
            }
            console.log("Product added successfully:", result);
            res.status(201).json({
                success: true,
                message: "Product added successfully",
                productId: result.insertId,
            });
        }
    );
}
