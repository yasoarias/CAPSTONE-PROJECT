<template>
  <div class="homepage">
    <Navbar
      @openLoginModal="openLoginModal"
      @openRegisterModal="openRegisterModal"
      @logout="handleLogout"
    />

    <main class="main-content">
      <div class="hero">
        <div class="hero-overlay">
          <img
            src="@/assets/contentimage.png"
            alt="Razz Rel Events logo"
            class="hero-logo"
          />
        </div>
        <button class="book-now" @click="handleBookNowClick">BOOK NOW</button>
      </div>
    </main>

   <StatisticsSection />

    <!-- Explore Our Services Section -->
    <div class="services-section">
      <h2>EXPLORE OUR SERVICES</h2>
      <div class="services-grid">
        <div class="service-item">
          <router-link to="/packages/wedding">
            <img src="@/assets/wedding.png" alt="Wedding" />
            <h3>Wedding</h3>
          </router-link>
        </div>
        <div class="service-item">
          <router-link to="/packages/debut">
            <img src="@/assets/debut.png" alt="Debut" />
            <h3>Debut</h3>
          </router-link>
        </div>
        <div class="service-item">
          <router-link to="/packages/kiddie-party">
            <img src="@/assets/kiddie.png" alt="Kiddie Party" />
            <h3>Kiddie Party</h3>
          </router-link>
        </div>
        <div class="service-item">
          <router-link to="/packages/christening">
            <img src="@/assets/christening.png" alt="Christening" />
            <h3>Christening</h3>
          </router-link>
        </div>
      </div>
    </div>
 <!-- Add Featured Events Section -->
    <section class="featured-events">
      <h2 class="section-title">Featured Events</h2>
      <div class="events-grid">
        <div class="event-card">
          <div class="event-image">
            <img src="@/assets/wedding-featured.jpg" alt="Luxury Wedding" />
          </div>
          <div class="event-content">
            <span class="event-tag">Wedding</span>
            <h3>Luxury Beach Wedding</h3>
            <p>An elegant beachfront celebration with stunning sunset views</p>
          </div>
        </div>
        <div class="event-card">
          <div class="event-image">
            <img src="@/assets/debut-featured.jpg" alt="Grand Debut" />
          </div>
          <div class="event-content">
            <span class="event-tag">Debut</span>
            <h3>Enchanted Garden Debut</h3>
            <p>A magical coming-of-age celebration in a garden setting</p>
          </div>
        </div>
        <div class="event-card">
          <div class="event-image">
            <img src="@/assets/christening-featured.jpg" alt="Christening" />
          </div>
          <div class="event-content">
            <span class="event-tag">Christening</span>
            <h3>Angelic Celebration</h3>
            <p>A blessed day filled with love and precious moments</p>
          </div>
        </div>
      </div>
    </section>
    <TestimonialsSection />
    
    


    <!-- About Us Section -->
    <!-- <AboutUS /> -->
    <!-- Add Why Choose Us Section -->
    <section class="why-choose-us">
      <h2 class="section-title">Why Choose Razz Rel Events?</h2>
      <div class="features-grid">
        <div class="feature-card">
          <i class="fas fa-gem"></i>
          <h3>Premium Quality</h3>
          <p>We deliver excellence in every detail of your special event</p>
        </div>
        <div class="feature-card">
          <i class="fas fa-clock"></i>
          <h3>Timely Execution</h3>
          <p>Perfect timing and coordination for a seamless experience</p>
        </div>
        <div class="feature-card">
          <i class="fas fa-hand-holding-heart"></i>
          <h3>Personalized Care</h3>
          <p>Dedicated team ensuring your vision comes to life</p>
        </div>
        <div class="feature-card">
          <i class="fas fa-shield-alt"></i>
          <h3>Peace of Mind</h3>
          <p>Professional handling of every aspect of your event</p>
        </div>
      </div>
    </section>

    <!-- Login Modal -->
    <Login
      v-if="isModalOpen && activeModal === 'login'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @login="handleLogin"
      @loginComplete="handleLoginComplete"
      @switchToRegister="switchToRegister"
    />

    <!-- Register Modal -->
    <Register
      v-if="isModalOpen && activeModal === 'register'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @register="handleRegister"
      @switchToLogin="switchToLogin"
    />

    <!-- New Process Section -->
    <section class="process-section">
      <h2 class="section-title">How It Works</h2>
      <div class="process-steps">
        <div class="step">
          <div class="step-icon">
            <i class="fas fa-search"></i>
          </div>
          <h3>Browse Packages</h3>
          <p>Explore our carefully curated event packages</p>
        </div>
        <div class="step">
          <div class="step-icon">
            <i class="fas fa-calendar-alt"></i>
          </div>
          <h3>Choose Date</h3>
          <p>Select your preferred event date</p>
        </div>
        <div class="step">
          <div class="step-icon">
            <i class="fas fa-check-circle"></i>
          </div>
          <h3>Book Event</h3>
          <p>Confirm your booking and we'll handle the rest</p>
        </div>
      </div>
    </section>

    <!-- FAQ Section -->
    <FaqSection />

    <!-- ChatBot -->
    <ChatBot />
  

    
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import Navbar from "./Navbar.vue";
import AboutUS from "./aboutUS.vue";
import Login from "./login.vue";
import Register from "./register.vue";
import FaqSection from "./guest/FaqSection.vue";
import ChatBot from "./ChatBot.vue";
import StatisticsSection from "./guest/StatisticsSection.vue";
import TestimonialsSection from "./guest/TestimonialsSection.vue";

const isModalOpen = ref(false);
const activeModal = ref("login");

const router = useRouter();

// Remove or comment out the following code block:
/*
onMounted(() => {
  const isLoggedIn = localStorage.getItem('user') !== null;
  if (isLoggedIn) {
    router.push('/gallery');
  }
});
*/

const openLoginModal = () => {
  isModalOpen.value = true;
  activeModal.value = "login";
};

const openRegisterModal = () => {
  isModalOpen.value = true;
  activeModal.value = "register";
};

const closeModal = () => {
  isModalOpen.value = false;
};

const switchToRegister = () => {
  activeModal.value = "register";
};

const switchToLogin = () => {
  activeModal.value = "login";
};

const handleBookNowClick = () => {
  isModalOpen.value = true;
  activeModal.value = "login";
};

const handleLogin = (credentials) => {
  // Implement login logic
  console.log("Login with:", credentials);
  closeModal();
};

const handleRegister = async (userData) => {
  try {
    const response = await fetch("http://localhost:3000/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    });

    const data = await response.json();

    if (data.success) {
      console.log("Registration successful");
      switchToLogin();
    } else {
      console.error("Registration failed:", data.message);
    }
  } catch (error) {
    console.error("Error during registration:", error);
  }
};

const handleLogout = () => {
  // Implement any additional logout logic if needed
  console.log("User logged out");
};

const handleLoginComplete = async () => {
  // await router.push("/");
  console.log(role);
};

// Comment out Tawk.to implementation
/*
onMounted(() => {
  setTimeout(() => {
    var Tawk_API = window.Tawk_API || {};
    var Tawk_LoadStart = new Date();
    
    (function() {
      var s1 = document.createElement("script");
      var s0 = document.getElementsByTagName("script")[0];
      s1.async = true;
      s1.src = 'https://embed.tawk.to/674302b32480f5b4f5a33fbb/1ides53qb';
      s1.charset = 'UTF-8';
      s1.setAttribute('crossorigin', '*');
      if (s0) {
        s0.parentNode.insertBefore(s1, s0);
      } else {
        document.head.appendChild(s1);
      }
    })();
  }, 1000);
});
*/
</script>

<style scoped>
.hero {
  position: relative;
  width: 100%;
  height: 100vh;
  background-image: url("@/assets/hero-image.jpg"); /* Update with your actual hero image path */
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
}

.hero-overlay {
  position: absolute;
  top: 36%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  color: white;
}

.hero-logo {
  width: 40rem; /* Adjust as needed */
  margin-bottom: 1rem;
}

.hero-overlay h1 {
  font-size: 2.5rem;
  margin-bottom: 0.5rem;
}

.hero-overlay p {
  font-size: 1.2rem;
}

.book-now {
  position: absolute;
  bottom: 20%;
  padding: 15px 50px;
  font-size: 1.2rem;
  background-color: AEC0C2;
  opacity: 0.8;
  color: black;
  border: none;
  border-radius: 15px;
  cursor: pointer;
  font-weight: bold;
}

.services-section {
  text-align: center;
  padding: 2rem 0;
}

.services-grid {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
}

.service-item {
  width: 20%;
  margin: 1rem 0;
}

.service-item img {
  width: 100%;
  height: 250px;
  object-fit: cover;
  border-radius: 8px;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.service-item:hover img {
  transform: scale(1.05);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.service-item h3 {
  margin-top: 0.5rem;
  font-size: 1.2rem;
}

.service-item a {
  text-decoration: none;
}

.process-section {
  padding: 4rem 2rem;
  background-color: #f8f9fa;
}

.process-steps {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.step {
  text-align: center;
  padding: 2rem;
  background: white;
  border-radius: 15px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.step:hover {
  transform: translateY(-5px);
}

.step-icon {
  font-size: 2.5rem;
  color: #AEC0C2;
  margin-bottom: 1rem;
}

.step h3 {
  margin-bottom: 1rem;
  color: #333;
}

.step p {
  color: #666;
  font-size: 0.9rem;
  line-height: 1.6;
}

.section-title {
  text-align: center;
  font-size: 2rem;
  color: #333;
  margin: 2rem 0;
  text-transform: uppercase;
  font-weight: bold;
}

/* For dark mode compatibility */
:deep(.dark-mode) .section-title {
  color: #fff;
}

.featured-events {
  padding: 4rem 2rem;
  background-color: white;
}

.events-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.event-card {
  background: white;
  border-radius: 15px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.event-card:hover {
  transform: translateY(-5px);
}

.event-image {
  height: 200px;
  overflow: hidden;
}

.event-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.event-content {
  padding: 1.5rem;
}

.event-tag {
  background: #AEC0C2;
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 15px;
  font-size: 0.9rem;
}

.event-content h3 {
  margin: 1rem 0;
  color: #333;
}

.event-content p {
  color: #666;
  font-size: 0.9rem;
  line-height: 1.6;
}

.why-choose-us {
  padding: 4rem 2rem;
  background-color: #f8f9fa;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.feature-card {
  text-align: center;
  padding: 2rem;
  background: white;
  border-radius: 15px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.feature-card:hover {
  transform: translateY(-5px);
}

.feature-card i {
  font-size: 2.5rem;
  color: #AEC0C2;
  margin-bottom: 1rem;
}

.feature-card h3 {
  margin-bottom: 1rem;
  color: #333;
}

.feature-card p {
  color: #666;
  font-size: 0.9rem;
  line-height: 1.6;
}

@media (max-width: 768px) {
  .events-grid,
  .features-grid {
    grid-template-columns: 1fr;
    padding: 0 1rem;
  }
  
  .event-image {
    height: 180px;
  }
}

/* Add these dark mode styles */
:deep(.dark-mode) {
  .homepage {
    background-color: #1a1a1a;
  }

  .services-section {
    background-color: #1a1a1a;
    h2 {
      color: #fff;
    }
    h3 {
      color: #fff;
    }
  }

  .featured-events {
    background-color: #1a1a1a;
  }

  .event-card {
    background: #2d2d2d;
  }

  .event-content h3 {
    color: #fff;
  }

  .event-content p {
    color: #b3b3b3;
  }

  .why-choose-us {
    background-color: #242424;
  }

  .feature-card {
    background: #2d2d2d;
    h3 {
      color: #fff;
    }
    p {
      color: #b3b3b3;
    }
  }

  .process-section {
    background-color: #1a1a1a;
    .step {
      background: #2d2d2d;
      h3 {
        color: #fff;
      }
      p {
        color: #b3b3b3;
      }
    }
  }
}
</style>
