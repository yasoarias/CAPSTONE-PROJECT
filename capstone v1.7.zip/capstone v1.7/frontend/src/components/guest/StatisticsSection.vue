 <template>
  <section class="statistics-section">
    <div class="stats-container">
      <div class="stat-item">
        <div class="stat-icon">
          <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-content">
          <div class="stat-number" data-count="500">500+</div>
          <div class="stat-label">Events Completed</div>
        </div>
      </div>
      <div class="stat-item">
        <div class="stat-icon">
          <i class="fas fa-users"></i>
        </div>
        <div class="stat-content">
          <div class="stat-number" data-count="1000">1000+</div>
          <div class="stat-label">Happy Clients</div>
        </div>
      </div>
      <div class="stat-item">
        <div class="stat-icon">
          <i class="fas fa-award"></i>
        </div>
        <div class="stat-content">
          <div class="stat-number" data-count="10">10+</div>
          <div class="stat-label">Years Experience</div>
        </div>
      </div>
      <div class="stat-item">
        <div class="stat-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="stat-content">
          <div class="stat-number" data-count="6.9">6.9</div>
          <div class="stat-label">Average Rating</div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.statistics-section {
  padding: 4rem 2rem;
  background-color: white;
  position: relative;
  overflow: hidden;
}

.stats-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
}

.stat-item {
  text-align: center;
  padding: 2.5rem 2rem;
  background: white;
  border-radius: 20px;
  transition: all 0.3s ease;
  position: relative;
  border: 1px solid rgba(174, 192, 194, 0.1);
  box-shadow: 
    0 4px 6px rgba(0, 0, 0, 0.05),
    0 10px 15px rgba(174, 192, 194, 0.1);
}

.stat-item:hover {
  transform: translateY(-5px);
  box-shadow: 
    0 8px 12px rgba(0, 0, 0, 0.08),
    0 16px 24px rgba(174, 192, 194, 0.15);
}

.stat-icon {
  margin-bottom: 1.5rem;
  background: linear-gradient(135deg, #AEC0C2 0%, #8fa3a5 100%);
  width: 70px;
  height: 70px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
}

.stat-icon i {
  font-size: 2rem;
  color: white;
}

.stat-content {
  position: relative;
  z-index: 1;
}

.stat-number {
  font-size: 2.8rem;
  font-weight: 700;
  color: #333;
  margin-bottom: 0.5rem;
  background: linear-gradient(135deg, #333 0%, #666 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.stat-label {
  color: #666;
  font-size: 1.1rem;
  font-weight: 500;
}

:deep(.dark-mode) {
  .statistics-section {
    background-color: #1a1a1a;
  }

  .stat-item {
    background: #2d2d2d;
    border-color: rgba(174, 192, 194, 0.05);
    box-shadow: 
      0 4px 6px rgba(0, 0, 0, 0.2),
      0 10px 15px rgba(0, 0, 0, 0.15);
  }

  .stat-item:hover {
    box-shadow: 
      0 8px 12px rgba(0, 0, 0, 0.25),
      0 16px 24px rgba(0, 0, 0, 0.2);
  }

  .stat-number {
    background: linear-gradient(135deg, #fff 0%, #b3b3b3 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .stat-label {
    color: #b3b3b3;
  }
}

@media (max-width: 768px) {
  .stats-container {
    gap: 1.5rem;
    padding: 0.5rem;
  }

  .stat-item {
    padding: 2rem 1.5rem;
  }

  .stat-icon {
    width: 60px;
    height: 60px;
  }

  .stat-number {
    font-size: 2.2rem;
  }
}
</style>