 <template>
  <section class="testimonials-section">
    <h2 class="section-title">What Our Clients Say</h2>
    <div class="testimonials-grid">
      <div class="testimonial-card">
        <div class="testimonial-image">
          <img src="@/assets/testimonial-1.jpg" alt="Wedding event" />
        </div>
        <div class="rating">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <p class="testimonial-text">
          "Razz Rel Events made our wedding absolutely magical. Their attention to detail and professionalism exceeded our expectations!"
        </p>
        <div class="client-info">
          <p class="client-name">Maria & John</p>
          <p class="event-type">Wedding, December 2023</p>
        </div>
      </div>
      <!-- Add 2 more testimonial cards with different content -->
    </div>
  </section>
</template>

<style scoped>
.testimonials-section {
  padding: 4rem 2rem;
  background-color: #f8f9fa;
  position: relative;
  overflow: hidden;
}

.testimonials-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
}

.testimonial-card {
  background: white;
  border-radius: 20px;
  padding: 2.5rem;
  border: 1px solid rgba(174, 192, 194, 0.1);
  box-shadow: 
    0 4px 6px rgba(0, 0, 0, 0.02),
    0 10px 15px rgba(174, 192, 194, 0.1),
    0 0 40px rgba(174, 192, 194, 0.06);
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  position: relative;
}

.testimonial-card:hover {
  transform: translateY(-8px);
  box-shadow: 
    0 8px 12px rgba(0, 0, 0, 0.04),
    0 16px 24px rgba(174, 192, 194, 0.15),
    0 0 50px rgba(174, 192, 194, 0.08);
}

.testimonial-image {
  width: 110px;
  height: 110px;
  margin: 0 auto 2rem;
  border-radius: 50%;
  overflow: hidden;
  border: 4px solid rgba(174, 192, 194, 0.1);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.rating {
  color: #ffd700;
  margin-bottom: 1.5rem;
  text-align: center;
  filter: drop-shadow(0 2px 4px rgba(255, 215, 0, 0.2));
}

.rating i {
  margin: 0 2px;
  font-size: 1.2rem;
}

.testimonial-text {
  font-style: italic;
  color: #666;
  margin-bottom: 2rem;
  text-align: center;
  line-height: 1.8;
  position: relative;
  padding: 0 1rem;
}

.testimonial-text::before,
.testimonial-text::after {
  content: '"';
  position: absolute;
  font-size: 3rem;
  color: rgba(174, 192, 194, 0.2);
  line-height: 1;
}

.testimonial-text::before {
  left: -0.5rem;
  top: -1rem;
}

.testimonial-text::after {
  right: -0.5rem;
  bottom: -2rem;
}

:deep(.dark-mode) {
  .testimonials-section {
    background-color: #242424;
  }

  .testimonial-card {
    background: #2d2d2d;
    border-color: rgba(174, 192, 194, 0.05);
    box-shadow: 
      0 4px 6px rgba(0, 0, 0, 0.2),
      0 10px 15px rgba(0, 0, 0, 0.15),
      0 0 40px rgba(0, 0, 0, 0.1);
  }

  .testimonial-card:hover {
    box-shadow: 
      0 8px 12px rgba(0, 0, 0, 0.25),
      0 16px 24px rgba(0, 0, 0, 0.2),
      0 0 50px rgba(0, 0, 0, 0.15);
  }

  .testimonial-image {
    border-color: rgba(174, 192, 194, 0.08);
  }

  .testimonial-text::before,
  .testimonial-text::after {
    color: rgba(174, 192, 194, 0.1);
  }
}
</style>