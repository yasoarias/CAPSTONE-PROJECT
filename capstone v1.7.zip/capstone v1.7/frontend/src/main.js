import { createApp } from "vue";
import "./style.css";
import "./style.scss";
import App from "./App.vue";
import router from "./router";
import "@fortawesome/fontawesome-free/css/all.min.css";
import { initEmailJS } from "./services/emailService";

// Initialize EmailJS
initEmailJS();

const app = createApp(App);
app.use(router).mount("#app");
