const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth"); // Assuming you have auth middleware

router.put("/profile/update", auth, async (req, res) => {
  try {
    const { fullName, email, contactNo } = req.body;

    // Validate input
    if (!fullName || !email || !contactNo) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    // Get user from database
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Update user fields
    user.fullName = fullName;
    user.email = email;
    user.contactNo = contactNo;

    // Save updated user
    const updatedUser = await user.save();

    // Return response
    res.json({
      success: true,
      message: "Profile updated successfully",
      user: {
        id: updatedUser._id,
        fullName: updatedUser.fullName,
        email: updatedUser.email,
        contactNo: updatedUser.contactNo,
        profilePicture: updatedUser.profilePicture,
      },
    });
  } catch (error) {
    console.error("Profile update error:", error);
    res.status(400).json({
      success: false,
      message: error.message || "Failed to update profile",
    });
  }
});

router.post("/verify-email", authenticateToken, async (req, res) => {
  try {
    const { userId } = req.body;

    // Update user's email verification status
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { emailVerified: true },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({
      success: true,
      message: "Email verification status updated",
      user: updatedUser,
    });
  } catch (error) {
    console.error("Error updating email verification:", error);
    res.status(500).json({ message: "Failed to update verification status" });
  }
});

router.post("/profile/update-verification", auth, async (req, res) => {
  try {
    const { userId, verificationType, verified } = req.body;

    // Create update object dynamically
    const updateField = {};
    updateField[`${verificationType}Verified`] = verified;

    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { $set: updateField },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    res.json({
      success: true,
      message: `${verificationType} verification updated successfully`,
      user: updatedUser,
    });
  } catch (error) {
    console.error("Error updating verification status:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update verification status",
    });
  }
});

router.post("/profile/update", auth, async (req, res) => {
  try {
    const { fullName, email, phoneNumber, emailVerified, phoneVerified } =
      req.body;

    const query = `
      UPDATE users 
      SET fullName = ?,
          email = ?,
          contactNo = ?,
          emailVerified = ?,
          phoneVerified = ?
      WHERE id = ?
    `;

    db.query(
      query,
      [fullName, email, phoneNumber, emailVerified, phoneVerified, req.user.id],
      (err, result) => {
        if (err) {
          console.error("Error updating user:", err);
          return res.status(500).json({
            success: false,
            message: "Failed to update profile",
          });
        }

        // Return updated user data
        const userData = {
          id: req.user.id,
          fullName,
          email,
          phoneNumber,
          emailVerified,
          phoneVerified,
        };

        res.json({
          success: true,
          message: "Profile updated successfully",
          user: userData,
        });
      }
    );
  } catch (error) {
    console.error("Profile update error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update profile",
    });
  }
});
