<template>
  <div
    class="chat-widget"
    :class="{ 'chat-open': isOpen, 'dark-mode': isDarkMode }"
  >
    <!-- Chat Button -->
    <button
      class="chat-button"
      @click="toggleChat"
      :class="{ 'dark-mode': isDarkMode }"
    >
      <div class="chat-button-content">
        <img
          src="@/assets/contentimage.png"
          alt="Razz Rel Events"
          class="chat-logo"
        />
        <span v-if="!isOpen">Need help?</span>
        <i :class="isOpen ? 'fas fa-times' : 'fas fa-comments'"></i>
      </div>
    </button>

    <!-- Chat Window -->
    <div class="chat-window" v-if="isOpen" :class="{ 'dark-mode': isDarkMode }">
      <div class="chat-header">
        <img
          src="@/assets/contentimage.png"
          alt="Razz Rel Events"
          class="chat-logo"
        />
        <div class="chat-header-text">
          <h3>Razz Rel Events Support</h3>
          <span class="online-status">Online</span>
        </div>
      </div>

      <div class="chat-messages" ref="messageContainer">
        <div
          v-for="(message, index) in messages"
          :key="index"
          :class="[
            'message',
            message.type,
            { 'with-options': message.options },
          ]"
        >
          <div class="message-content">
            {{ message.text }}
            <div v-if="message.options" class="message-options">
              <button
                v-for="option in message.options"
                :key="option"
                @click="handleOptionSelect(option)"
              >
                {{ option }}
              </button>
            </div>
          </div>
          <span class="message-time">{{ formatTime(message.timestamp) }}</span>
        </div>
        <div v-if="isTyping" class="message bot typing">
          <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      </div>

      <div class="chat-input">
        <input
          type="text"
          v-model="userInput"
          @keyup.enter="sendMessage"
          placeholder="Type your message..."
          :disabled="isTyping"
        />
        <button @click="sendMessage" :disabled="!userInput.trim() || isTyping">
          <i class="fas fa-paper-plane"></i>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, onUnmounted } from "vue";
import { useRouter, useRoute } from "vue-router";

const router = useRouter();
const route = useRoute();
const isOpen = ref(false);
const messages = ref([]);
const userInput = ref("");
const isTyping = ref(false);
const messageContainer = ref(null);
const isDarkMode = ref(false);
const isAdmin = ref(false);
const isLiveChat = ref(false);
const chatId = ref(null);

// Singleton pattern
const CHAT_INSTANCE_KEY = "chat-instance";

// Utility functions
const formatTime = (timestamp) => {
  const date = new Date(timestamp);
  const options = {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Manila",
  };
  return date.toLocaleString("en-PH", options);
};

// Clean up on unmount
onUnmounted(() => {
  if (window[CHAT_INSTANCE_KEY]) {
    delete window[CHAT_INSTANCE_KEY];
  }
});

// Check for existing instance on mount
const checkExistingInstance = () => {
  if (window[CHAT_INSTANCE_KEY]) {
    const parentElement = document.querySelector(".chat-widget")?.parentElement;
    if (parentElement) {
      parentElement.removeChild(document.querySelector(".chat-widget"));
    }
    return true;
  }
  window[CHAT_INSTANCE_KEY] = true;
  return false;
};

// Initial greeting based on current route
onMounted(() => {
  const currentUser = localStorage.getItem("user");
  if (currentUser) {
    const user = JSON.parse(currentUser);
    isAdmin.value = user.role === "admin";
  }

  // Modified initial greeting based on user role
  if (!isAdmin.value) {
    addBotMessage({
      text: "Hello! Welcome to Razz Rel Events. How can I assist you today?",
      options: ["Book an Event", "View Packages", "Contact Support"],
    });
  }

  // Initial dark mode state
  isDarkMode.value = document.documentElement.classList.contains("dark-mode");

  // Watch for dark mode changes
  const observer = new MutationObserver(() => {
    isDarkMode.value = document.documentElement.classList.contains("dark-mode");
  });

  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["class"],
  });
});

const toggleChat = () => {
  isOpen.value = !isOpen.value;
};

const addBotMessage = (messageData) => {
  isTyping.value = true;
  setTimeout(() => {
    messages.value.push({
      type: "bot",
      timestamp: new Date(),
      ...messageData,
    });
    isTyping.value = false;
  }, 1000);
};

const handleOptionSelect = async (option) => {
  messages.value.push({
    type: "user",
    text: option,
    timestamp: new Date(),
  });

  if (option === "Contact Support") {
    isLiveChat.value = true;
    chatId.value = `chat_${Date.now()}`;

    addBotMessage({
      text: "Connecting you to a live agent... Please wait.",
    });

    try {
      const token = localStorage.getItem("token");
      const userId = localStorage.getItem("userId");

      if (!token || !userId) {
        throw new Error("Authentication required");
      }

      const response = await fetch(
        "http://localhost:3000/api/chat/initialize",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            chatId: chatId.value,
            userId: userId,
            status: "active",
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to initialize chat");
      }

      addBotMessage({
        text: "You're now connected with a live agent. How can we help you today?",
      });
    } catch (error) {
      console.error("Error initializing chat:", error);
      addBotMessage({
        text:
          error.message === "Authentication required"
            ? "Please log in to chat with a live agent."
            : "Sorry, we couldn't connect you to a live agent. Please try again later.",
      });
    }
  } else if (option === "View Packages" || option === "View Other Packages") {
    addBotMessage({
      text: "Please select which package you're interested in:",
      options: ["Wedding", "Debut", "Kiddie Party", "Christening"],
    });
  } else if (
    ["Wedding", "Debut", "Kiddie Party", "Christening"].includes(option)
  ) {
    const routes = {
      Wedding: "/packages/wedding",
      Debut: "/packages/debut",
      "Kiddie Party": "/packages/kiddie-party",
      Christening: "/packages/christening",
    };

    addBotMessage({
      text: `Great choice! Redirecting you to our ${option.toLowerCase()} packages...`,
    });

    setTimeout(() => {
      router.push(routes[option]);
      isOpen.value = false;
    }, 1500);
  } else {
    const response = getBotResponse(option);
    addBotMessage({ text: response });
  }
};

const sendMessage = async () => {
  if (!userInput.value.trim()) return;

  const messageText = userInput.value;
  userInput.value = "";

  messages.value.push({
    type: "user",
    text: messageText,
    timestamp: new Date(),
  });

  if (isLiveChat.value) {
    try {
      await fetch("http://localhost:3000/api/chat/message", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chatId: chatId.value,
          message: messageText,
          sender: "user",
        }),
      });
    } catch (error) {
      console.error("Error sending message:", error);
    }
  } else {
    // Simulate bot response
    setTimeout(() => {
      const response = getBotResponse(messageText);
      messages.value.push({
        type: "bot",
        text: response,
        timestamp: new Date(),
      });
    }, 1000);
  }
};

const getBotResponse = (input) => {
  const lowerInput = input.toLowerCase();

  // Basic response logic
  if (lowerInput.includes("book") || lowerInput.includes("reservation")) {
    return 'To book an event, please click the "Book Now" button on our homepage or call us at 09123456789.';
  } else if (lowerInput.includes("price") || lowerInput.includes("package")) {
    return "We offer various packages for different events. Please visit our packages page or contact us for detailed pricing.";
  } else if (
    lowerInput.includes("location") ||
    lowerInput.includes("address")
  ) {
    return "You can visit us at [Your Address]. Feel free to contact us for directions!";
  }

  return "Thank you for your message. For specific inquiries, please call us at 09123456789 or email us at razz.rel.events@gmail.com";
};

// Auto-scroll to latest message
watch(
  () => messages.value.length,
  () => {
    setTimeout(() => {
      if (messageContainer.value) {
        messageContainer.value.scrollTop = messageContainer.value.scrollHeight;
      }
    }, 100);
  }
);
</script>

<style scoped>
.chat-widget {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 9999;
  filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.1));
}

.chat-button {
  background: rgba(174, 192, 194, 0.95);
  backdrop-filter: blur(10px);
  border: none;
  border-radius: 50px;
  padding: 8px 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 10px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
  transition: all 0.3s ease;
}

.chat-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
}

.chat-button-content {
  display: flex;
  align-items: center;
  gap: 8px;
}

.chat-logo {
  width: 24px;
  height: 24px;
  border-radius: 50%;
}

.chat-button span {
  color: #ffffff;
  font-size: 14px;
  font-weight: 500;
}

.chat-button i {
  font-size: 16px;
  color: #ffffff;
}

.chat-window {
  position: absolute;
  bottom: calc(100% + 16px);
  right: 0;
  width: 300px;
  height: 400px;
  background: #f8f9fa;
  border-radius: 16px;
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.15), 0 8px 16px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.chat-header {
  background: linear-gradient(145deg, #aec0c2, #95a5a6);
  padding: 12px 16px;
  color: white;
  display: flex;
  align-items: center;
  gap: 8px;
}

.chat-header .chat-logo {
  width: 32px;
  height: 32px;
}

.chat-header-text h3 {
  font-size: 14px;
  margin: 0;
}

.online-status {
  font-size: 12px;
  opacity: 0.9;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  background: #ffffff;
  gap: 8px;
}

.message {
  max-width: 85%;
  padding: 10px 14px;
  border-radius: 14px;
  font-size: 13px;
  margin-bottom: 8px;
  background: #f1f3f5;
  color: #2c3e50;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
}

.message-time {
  font-size: 10px;
  opacity: 0.7;
  margin-top: 4px;
}

.chat-input {
  padding: 12px;
  background: #ffffff;
  border-top: 1px solid #e9ecef;
  display: flex;
  gap: 8px;
}

.chat-input input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #ced4da;
  border-radius: 20px;
  font-size: 13px;
  background: #ffffff;
  color: #2c3e50;
}

.message-options {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}

.message-options button {
  background: #ffffff;
  border: 1px solid #aec0c2;
  color: #6c757d;
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.message-options button:hover {
  background: #aec0c2;
  color: white;
  transform: translateY(-1px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* Dark mode styles */
.dark-mode.chat-button {
  background: rgba(52, 58, 64, 0.95);
}

.dark-mode.chat-button span,
.dark-mode.chat-button i {
  color: #ffffff;
}

.dark-mode .chat-window {
  background: #212529;
  color: #fff;
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.3), 0 8px 16px rgba(0, 0, 0, 0.2);
}

.dark-mode .chat-header {
  background: linear-gradient(145deg, #495057, #343a40);
}

.dark-mode .chat-messages {
  background: #2c3034;
}

.dark-mode .message {
  background: #343a40;
  color: #e9ecef;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.dark-mode .chat-input {
  background: #212529;
  border-top: 1px solid #343a40;
}

.dark-mode .chat-input input {
  background: #343a40;
  border: 1px solid #495057;
  color: #e9ecef;
}

.dark-mode .message-options button {
  background: #343a40;
  border: 1px solid #495057;
  color: #adb5bd;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.dark-mode .message-options button:hover {
  background: #495057;
  color: #ffffff;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}
</style>
