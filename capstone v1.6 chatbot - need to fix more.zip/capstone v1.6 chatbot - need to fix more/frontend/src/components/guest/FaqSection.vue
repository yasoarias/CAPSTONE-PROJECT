<template>
  <section class="faq-section">
    <h2 class="section-title">Frequently Asked Questions</h2>
    <div class="faq-container">
      <div
        v-for="(faq, index) in faqs"
        :key="index"
        class="faq-item"
        :class="{ active: activeFaq === index }"
      >
        <div class="faq-question" @click="toggleFaq(index)">
          <h3>{{ faq.question }}</h3>
          <i
            class="fas fa-chevron-down"
            :class="{ rotate: activeFaq === index }"
          ></i>
        </div>
        <div class="faq-answer" v-show="activeFaq === index">
          <p>{{ faq.answer }}</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref } from "vue";

const activeFaq = ref(null);
const faqs = ref([
  {
    question: "How do I book an event?",
    answer:
      "Browse our packages, select your preferred option, and click 'Book Now'. You'll need to create an account or log in to complete your booking.",
  },
  {
    question: "What types of events do you handle?",
    answer:
      "We specialize in Weddings, Debuts, Kiddie Parties, and Christenings. Each event type has customizable packages to suit your needs.",
  },
  {
    question: "Do you offer customizable packages?",
    answer:
      "Yes, all our packages can be customized to match your specific requirements and preferences. Contact us for custom arrangements.",
  },
  {
    question: "What is your cancellation policy?",
    answer:
      "Our cancellation policy varies depending on the package and timing. Please contact us directly for specific details about cancellations and refunds.",
  },
]);

const toggleFaq = (index) => {
  activeFaq.value = activeFaq.value === index ? null : index;
};
</script>

<style scoped>
.faq-section {
  padding: 4rem 2rem;
  max-width: 800px;
  margin: 0 auto;
}

.faq-container {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.faq-item {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.faq-question {
  padding: 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  background: white;
}

.faq-question h3 {
  margin: 0;
  font-size: 1.1rem;
  color: #333;
}

.faq-question i {
  transition: transform 0.3s ease;
}

.faq-question i.rotate {
  transform: rotate(180deg);
}

.faq-answer {
  padding: 0 1.5rem 1.5rem;
  color: #666;
}

.active {
  border-left: 4px solid #aec0c2;
}
</style>
