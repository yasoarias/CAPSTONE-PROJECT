<template>
  <div class="admin-chat" :class="{ 'dark-mode': isDarkMode }">
    <div class="chat-list">
      <div
        v-for="chat in activeChats"
        :key="chat.id"
        :class="['chat-item', { active: selectedChat?.id === chat.id }]"
        @click="selectChat(chat)"
      >
        <span class="user-info">Guest {{ chat.id }}</span>
        <span class="timestamp">{{
          formatTime(chat.lastMessage?.timestamp)
        }}</span>
      </div>
    </div>

    <div class="chat-area">
      <div v-if="selectedChat" class="chat-messages" ref="messageContainer">
        <div
          v-for="(message, index) in selectedChat.messages"
          :key="index"
          :class="['message', message.type]"
        >
          <div class="message-content">{{ message.text }}</div>
          <span class="message-time">{{ formatTime(message.timestamp) }}</span>
        </div>
      </div>

      <div class="chat-input" v-if="selectedChat">
        <input
          type="text"
          v-model="adminInput"
          @keyup.enter="sendAdminMessage"
          placeholder="Type your response..."
        />
        <button @click="sendAdminMessage">
          <i class="fas fa-paper-plane"></i>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";

const ws = new WebSocket("ws://localhost:8080");

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  if (data.type === "message") {
    // Add message to chat
    if (selectedChat.value?.id === data.chatId) {
      selectedChat.value.messages.push({
        text: data.message,
        sender: data.sender,
        timestamp: new Date(),
      });
    }
  }
};

const sendAdminMessage = async () => {
  if (!adminInput.value.trim() || !selectedChat.value) return;

  const messageText = adminInput.value;
  adminInput.value = "";

  try {
    await fetch("http://localhost:3000/api/chat/message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify({
        chatId: selectedChat.value.id,
        message: messageText,
        sender: "admin",
      }),
    });

    ws.send(
      JSON.stringify({
        type: "message",
        chatId: selectedChat.value.id,
        message: messageText,
        sender: "admin",
      })
    );
  } catch (error) {
    console.error("Error sending message:", error);
  }
};
</script>
