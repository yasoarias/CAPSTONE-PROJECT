import emailjs from "@emailjs/browser";

const EMAILJS_SERVICE_ID = "service_2pggebm";
const EMAILJS_TEMPLATE_ID = "template_mhhby46";
const EMAILJS_PUBLIC_KEY = "Yk9QE_6jJUKTDiIKa";

export const initEmailJS = () => {
  emailjs.init(EMAILJS_PUBLIC_KEY);
};

export const sendVerificationEmail = async (email, otp, name) => {
  const templateParams = {
    to_email: email,
    otp: otp,
    user_name: name,
  };

  return await emailjs.send(
    EMAILJS_SERVICE_ID,
    EMAILJS_TEMPLATE_ID,
    templateParams,
    EMAILJS_PUBLIC_KEY
  );
};
