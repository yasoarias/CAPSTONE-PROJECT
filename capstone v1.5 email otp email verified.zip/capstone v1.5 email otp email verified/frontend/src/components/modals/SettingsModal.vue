<!-- frontend/src/components/SettingsModal.vue -->
<template>
  <div class="modal-overlay" @click="$emit('close')">
    <div class="modal-content" @click.stop>
      <h2 class="modal-title">Profile Settings</h2>
      <div class="profile-picture-section">
        <div class="profile-picture-container">
          <img
            :src="currentProfileImage"
            alt="Profile Picture"
            class="profile-picture"
            @error="handleImageError"
          />
        </div>
        <input
          type="file"
          @change="handleImageUpload"
          accept="image/*"
          ref="fileInput"
          style="display: none"
        />
        <button @click="$refs.fileInput.click()" class="change-picture-btn">
          Change Profile Picture
        </button>
      </div>
      <form @submit.prevent="saveSettings">
        <div class="form-group">
          <label for="fullName">Full Name:</label>
          <input
            type="text"
            id="fullName"
            v-model="formData.fullName"
            required
          />
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <div class="email-input-container">
            <input type="email" id="email" v-model="formData.email" required />
            <button
              v-if="!formData.emailVerified"
              @click="sendEmailVerification"
              type="button"
              class="verify-btn"
            >
              Verify
            </button>
            <span v-else class="verified-badge">
              <i class="fas fa-check-circle"></i>
            </span>
          </div>
        </div>
        <div class="form-group">
          <label for="phone">Phone Number:</label>
          <div class="phone-input-container">
            <input
              type="tel"
              id="phone"
              v-model="formData.phoneNumber"
              required
              pattern="[0-9]*"
            />
            <button
              v-if="!formData.phoneVerified"
              @click="sendPhoneVerification"
              type="button"
              class="verify-btn"
            >
              Verify
            </button>
            <span v-else class="verified-badge">
              <i class="fas fa-check-circle"></i>
            </span>
          </div>
        </div>
        <div class="form-actions">
          <button type="submit" class="save-btn">Save Changes</button>
          <button type="button" @click="$emit('close')" class="cancel-btn">
            Cancel
          </button>
        </div>
      </form>
    </div>
  </div>
  <div v-if="successMessage" class="notification-modal-overlay">
    <div class="notification-modal">
      <div class="success-icon">
        <i class="fas fa-check-circle"></i>
      </div>
      <div class="notification-content">
        <h3>Success!</h3>
        <p>{{ successMessage }}</p>
      </div>
    </div>
  </div>
  <div v-if="showOtpModal" class="otp-modal" @click="closeOtpModal">
    <div class="otp-content" @click.stop>
      <h2>Verify {{ verificationMode === "email" ? "Email" : "Phone" }}</h2>
      <p class="otp-message">{{ otpMessage }}</p>
      <div class="otp-input-container">
        <input
          type="text"
          v-model="otpCode"
          placeholder="Enter verification code"
          maxlength="6"
          class="otp-input"
        />
      </div>
      <div class="otp-buttons">
        <button @click="verifyOtp" class="verify-otp-btn">Verify</button>
        <button @click="closeOtpModal" class="cancel-otp-btn">Cancel</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import defaultProfilePicture from "@/assets/default-profile.png";
import { sendVerificationEmail } from "@/services/emailService";

const props = defineProps(["user", "token"]);
const emit = defineEmits(["close", "update-user"]);

const formData = ref({
  fullName: "",
  email: "",
  contactNo: "",
  emailVerified: false,
  phoneVerified: false,
});

const newProfileImage = ref(null);
const previewImage = ref(null);
const fileInput = ref(null);
const successMessage = ref("");
const currentProfileImage = ref(defaultProfilePicture);

const showOtpModal = ref(false);
const otpCode = ref("");
const otpMessage = ref("");
const verificationMode = ref("");
const generatedOtp = ref("");

onMounted(() => {
  // Load user data from localStorage
  const userData = JSON.parse(localStorage.getItem("user") || "{}");

  formData.value = {
    fullName: userData.fullName || "",
    email: userData.email || "",
    phoneNumber: userData.contactNo || "",
    emailVerified: userData.emailVerified || false,
    phoneVerified: userData.phoneVerified || false,
  };

  // Set profile image
  if (userData.profilePicture) {
    currentProfileImage.value = userData.profilePicture;
  }
});

const handleImageUpload = (event) => {
  const file = event.target.files[0];
  if (file) {
    newProfileImage.value = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      previewImage.value = e.target.result;
      currentProfileImage.value = e.target.result;
    };
    reader.readAsDataURL(file);
  }
};

const saveSettings = async () => {
  try {
    const formDataToSend = new FormData();
    formDataToSend.append("fullName", formData.value.fullName);
    formDataToSend.append("email", formData.value.email);
    formDataToSend.append("phoneNumber", formData.value.phoneNumber);
    formDataToSend.append("emailVerified", formData.value.emailVerified);
    formDataToSend.append("phoneVerified", formData.value.phoneVerified);

    if (fileInput.value && fileInput.value.files[0]) {
      formDataToSend.append("profilePicture", fileInput.value.files[0]);
    }

    const response = await fetch("http://localhost:3000/api/user/update", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${props.token}`,
      },
      body: formDataToSend,
    });

    if (!response.ok) {
      throw new Error("Failed to update profile");
    }

    const data = await response.json();

    // Update localStorage with verification status
    localStorage.setItem(
      "user",
      JSON.stringify({
        ...data.user,
        emailVerified: formData.value.emailVerified,
        phoneVerified: formData.value.phoneVerified,
      })
    );

    successMessage.value = "Profile updated successfully!";
    setTimeout(() => {
      successMessage.value = "";
      emit("close");
    }, 2500);
  } catch (error) {
    console.error("Error updating profile:", error);
    alert(error.message || "Failed to update profile");
  }
};

const handleImageError = (e) => {
  e.target.src = defaultProfilePicture;
};

const sendEmailVerification = async () => {
  try {
    verificationMode.value = "email";
    generatedOtp.value = Math.floor(100000 + Math.random() * 900000).toString();

    await sendVerificationEmail(
      formData.value.email,
      generatedOtp.value,
      formData.value.fullName
    );

    showOtpModal.value = true;
    otpMessage.value = "A verification code has been sent to your email.";
  } catch (error) {
    console.error("Failed to send email verification:", error);
    alert("Failed to send verification email. Please try again.");
  }
};

const sendPhoneVerification = async () => {
  try {
    verificationMode.value = "phone";
    generatedOtp.value = Math.floor(100000 + Math.random() * 900000).toString();

    // For testing, log the OTP to console
    console.log("Phone Verification OTP:", generatedOtp.value);

    // In production, you would send this via SMS
    // await sendSMSWithOTP(formData.value.contactNo, generatedOtp.value);

    showOtpModal.value = true;
    otpMessage.value = "A verification code has been sent to your phone.";
  } catch (error) {
    console.error("Failed to send phone verification:", error);
    alert("Failed to send verification SMS. Please try again.");
  }
};

const verifyOtp = async () => {
  try {
    if (otpCode.value === generatedOtp.value) {
      if (verificationMode.value === "email") {
        const result = await updateVerificationStatus("email");
        if (result.success) {
          formData.value.emailVerified = true;
          emit("update-user", { ...formData.value });
          
          // Update localStorage
          const userData = JSON.parse(localStorage.getItem("user") || "{}");
          userData.emailVerified = true;
          localStorage.setItem("user", JSON.stringify(userData));
          
          closeOtpModal();
          successMessage.value = "Email verified successfully!";
          setTimeout(() => {
            successMessage.value = "";
          }, 3000);
        }
      } else {
        // Handle phone verification similarly
        const result = await updateVerificationStatus("phone");
        if (result.success) {
          formData.value.phoneVerified = true;
          emit("update-user", { ...formData.value });
          
          // Update localStorage
          const userData = JSON.parse(localStorage.getItem("user") || "{}");
          userData.phoneVerified = true;
          localStorage.setItem("user", JSON.stringify(userData));
          
          closeOtpModal();
          successMessage.value = "Phone verified successfully!";
          setTimeout(() => {
            successMessage.value = "";
          }, 3000);
        }
      }
    } else {
      alert("Invalid verification code. Please try again.");
    }
  } catch (error) {
    console.error("Verification failed:", error);
    alert("Verification failed. Please try again.");
  }
};

const updateVerificationStatus = async (type) => {
  try {
    const response = await fetch(`http://localhost:3000/api/user/verify-${type}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${props.token}`,
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error("Verification error response:", errorData);
      throw new Error(errorData.message || `Failed to update ${type} verification status`);
    }

    const data = await response.json();
    
    if (!data.success) {
      throw new Error(data.message || `Failed to update ${type} verification status`);
    }

    // Update local user data
    if (data.user) {
      localStorage.setItem("user", JSON.stringify(data.user));
    }

    return data;
  } catch (error) {
    console.error(`Error updating ${type} verification:`, error);
    throw error;
  }
};

const closeOtpModal = () => {
  showOtpModal.value = false;
  otpCode.value = "";
  otpMessage.value = "";
  verificationMode.value = "";
};
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  padding: 2rem;
  border-radius: 12px;
  width: 90%;
  max-width: 400px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.modal-title {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #333;
  font-size: 1.5rem;
}

.profile-picture-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 1.5rem;
}

.profile-picture-container {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  overflow: hidden;
  margin-bottom: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.profile-picture {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.change-picture-btn {
  background-color: #4a90e2;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.change-picture-btn:hover {
  background-color: #3a7bc8;
}

.form-group {
  margin-bottom: 1.5rem;
  margin-right: 20px; /* Add margin to the right */
  position: relative;
  width: 100%; /* Ensure it takes full width */
}

label {
  display: block;
  margin-bottom: 0.5rem;
  color: #555;
  font-weight: bold;
}

input[type="text"],
input[type="email"],
input[type="tel"] {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
}

.unverified {
  position: absolute;
  right: 10px; /* Adjust as needed */
  top: 50%;
  transform: translateY(-50%);
  font-size: 0.75rem; /* Smaller font size */
  color: #e74c3c;
  cursor: pointer; /* Change cursor to pointer */
}

.unverified:hover {
  text-decoration: underline; /* Underline on hover */
}

.phone-input-container,
.email-input-container {
  position: relative;
  width: 100%; /* Ensure it takes full width */
}

.phone-input-container input,
.email-input-container input,
.form-group input {
  padding-right: 100px; /* Add padding to the right for the label */
  width: 100%; /* Ensure the input takes full width */
  box-sizing: border-box; /* Include padding in width calculation */
}

.unverified i {
  margin-right: 0.25rem;
}

.form-actions {
  display: flex;
  justify-content: space-between;
  margin-top: 2rem;
}

.save-btn,
.cancel-btn {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}

.save-btn {
  background-color: #2ecc71;
  color: white;
}

.save-btn:hover {
  background-color: #27ae60;
}

.cancel-btn {
  background-color: #e74c3c;
  color: white;
  margin-left: 10px; /* Add margin to separate buttons */
}

.cancel-btn:hover {
  background-color: #c0392b;
}

.email-input-container {
  position: relative;
  width: 100%; /* Ensure it takes full width */
}

.email-input-container input {
  padding-right: 100px; /* Add padding to the right for the label */
  width: 100%; /* Ensure the input takes full width */
  box-sizing: border-box; /* Include padding in width calculation */
}

.notification-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1200;
  animation: fadeIn 0.3s ease-in-out;
}

.notification-modal {
  background-color: white;
  padding: 30px;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 400px;
  width: 90%;
  animation: slideIn 0.3s ease-out;
}

.success-icon {
  font-size: 48px;
  color: #2ecc71;
  margin-bottom: 20px;
}

.notification-content {
  text-align: center;
}

.notification-content h3 {
  color: #2ecc71;
  margin: 0 0 10px 0;
  font-size: 24px;
}

.notification-content p {
  color: #666;
  margin: 0;
  font-size: 16px;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes slideIn {
  from {
    transform: translateY(-20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.otp-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.otp-content {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  width: 400px;
  max-width: 90%;
  text-align: center;
}

.otp-content h2 {
  margin: 0 0 1rem 0;
  font-size: 1.5rem;
  color: #333;
}

.otp-message {
  color: #666;
  margin-bottom: 1.5rem;
}

.otp-input-container {
  margin-bottom: 1.5rem;
}

.otp-input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  text-align: center;
  box-sizing: border-box;
}

.otp-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
}

.verify-otp-btn {
  padding: 0.75rem 2rem;
  background: #2ecc71;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.3s;
}

.verify-otp-btn:hover {
  background: #27ae60;
}

.cancel-otp-btn {
  padding: 0.75rem 2rem;
  background: #e74c3c;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.3s;
}

.cancel-otp-btn:hover {
  background: #c0392b;
}

/* Dark mode support */
.dark-mode .otp-content {
  background: #1a1a1a;
  color: white;
}

.dark-mode .otp-content h2 {
  color: white;
}

.dark-mode .otp-message {
  color: #ccc;
}

.dark-mode .otp-input {
  background: #2d2d2d;
  border-color: #404040;
  color: white;
}

.email-input-container,
.phone-input-container {
  position: relative;
  width: 100%;
}

.form-group input {
  width: 100%;
  padding: 0.75rem;
  padding-right: 80px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  box-sizing: border-box;
}

.verify-btn {
  position: absolute;
  right: 5px;
  top: 50%;
  transform: translateY(-50%);
  padding: 0.4rem 0.8rem;
  background: #2196f3;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.85rem;
  white-space: nowrap;
}

.verify-btn:hover {
  background: #1976d2;
}

.verified-badge {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: #4caf50;
  font-size: 1.2rem;
}

/* Dark mode support */
.dark-mode .form-group input {
  background: #2d2d2d;
  border-color: #404040;
  color: white;
}

.dark-mode .verify-btn {
  background: #1976d2;
}

.dark-mode .verify-btn:hover {
  background: #1565c0;
}
</style>
