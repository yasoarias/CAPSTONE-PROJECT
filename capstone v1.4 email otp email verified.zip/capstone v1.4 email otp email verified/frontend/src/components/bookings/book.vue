<template>
  <div class="book-page">
    <h1>Book Now</h1>
    <!-- Add your booking form or content here -->
  </div>
</template>

<script setup>
</script>

<style scoped>
.book-page {
  padding: 2rem;
  text-align: center;
}
</style>
