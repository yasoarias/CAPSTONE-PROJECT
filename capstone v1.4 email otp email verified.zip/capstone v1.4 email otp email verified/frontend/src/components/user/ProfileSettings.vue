<template>
  <div class="profile-settings-modal" v-if="isOpen">
    <div class="modal-content" :class="{ 'dark-mode': isDarkMode }">
      <h2>Profile Settings</h2>
      <div class="settings-container">
        <!-- Profile Picture Section -->
        <div class="profile-picture-section">
          <div class="profile-picture-container">
            <img :src="profileImage" alt="Profile Picture" />
          </div>
          <input
            type="file"
            @change="handleImageUpload"
            accept="image/*"
            style="display: none"
            ref="fileInput"
          />
          <button
            type="button"
            class="change-picture-btn"
            @click="$refs.fileInput.click()"
          >
            Change Profile Picture
          </button>
        </div>

        <!-- Profile Information Form -->
        <form @submit.prevent="handleSubmit" class="profile-form">
          <div class="form-group">
            <label>Full Name:</label>
            <input type="text" v-model="formData.fullName" required />
          </div>

          <div class="form-group">
            <label>Email:</label>
            <div class="email-input-container">
              <input type="email" v-model="formData.email" required />
              <span
                class="verification-status"
                :class="{ verified: formData.emailVerified }"
              >
                {{ formData.emailVerified ? "Verified" : "Unverified" }}
              </span>
              <button
                v-if="!formData.emailVerified"
                @click="sendEmailVerification"
                type="button"
                class="verify-btn"
              >
                Verify Email
              </button>
            </div>
          </div>

          <div class="form-group">
            <label>Phone Number:</label>
            <div class="phone-input-container">
              <div class="country-code">+63</div>
              <input
                type="tel"
                v-model="formData.phoneNumber"
                required
                placeholder="Enter phone number"
                pattern="[0-9]*"
              />
              <span
                class="verification-status"
                :class="{ verified: formData.phoneVerified }"
              >
                {{ formData.phoneVerified ? "Verified" : "Unverified" }}
              </span>
              <button
                v-if="!formData.phoneVerified"
                @click="sendPhoneVerification"
                type="button"
                class="verify-btn"
              >
                Verify Phone
              </button>
            </div>
          </div>

          <!-- Password Form -->
          <div class="password-form">
            <h3>Change Password</h3>
            <div class="form-group">
              <label>Current Password:</label>
              <input
                type="password"
                v-model="passwordData.currentPassword"
                placeholder="Enter your current password"
              />
            </div>

            <div class="form-group">
              <label>New Password:</label>
              <input
                type="password"
                v-model="passwordData.newPassword"
                placeholder="Enter new password"
                minlength="8"
              />
            </div>

            <div class="form-group">
              <label>Confirm New Password:</label>
              <input
                type="password"
                v-model="passwordData.confirmPassword"
                placeholder="Confirm your new password"
              />
            </div>
          </div>

          <!-- Action Buttons -->
          <div class="button-group">
            <button type="submit" class="save-btn">Save Changes</button>
            <button type="button" class="cancel-btn" @click="$emit('close')">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Add OTP Modal -->
  <div v-if="showOtpModal" class="otp-modal">
    <div class="otp-content">
      <h3>Enter Verification Code</h3>
      <p>{{ otpMessage }}</p>
      <input
        type="text"
        v-model="otpCode"
        placeholder="Enter OTP"
        maxlength="6"
      />
      <div class="otp-buttons">
        <button @click="verifyOtp" class="verify-btn">Verify</button>
        <button @click="closeOtpModal" class="cancel-btn">Cancel</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useAuth } from "@/composables/useAuth";
import { sendVerificationEmail } from "@/services/emailService";
import axios from "axios";

const props = defineProps({
  isOpen: {
    type: Boolean,
    required: true,
  },
});

const emit = defineEmits(["close", "success"]);
const { token } = useAuth();

const formData = ref({
  fullName: "",
  email: "",
  phoneNumber: "",
});

const passwordData = ref({
  currentPassword: "",
  newPassword: "",
  confirmPassword: "",
});

const newProfileImage = ref(null);
const profileImage = ref("default-profile-image.jpg");

// Initialize form data with user info
onMounted(() => {
  const userData = JSON.parse(localStorage.getItem("user") || "{}");
  formData.value = {
    fullName: userData.fullName || "",
    email: userData.email || "",
    phoneNumber: userData.contactNo || "",
  };
  if (userData.profilePicture) {
    profileImage.value = userData.profilePicture.startsWith("http")
      ? userData.profilePicture
      : `http://localhost:3000${userData.profilePicture}`;
  }
});

const handleImageUpload = (event) => {
  const file = event.target.files[0];
  if (file) {
    newProfileImage.value = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      profileImage.value = e.target.result;
    };
    reader.readAsDataURL(file);
  }
};

const handleSubmit = async () => {
  try {
    // Update profile
    await updateProfile();

    // Update password if any password field is filled
    if (
      passwordData.value.currentPassword ||
      passwordData.value.newPassword ||
      passwordData.value.confirmPassword
    ) {
      if (
        passwordData.value.newPassword !== passwordData.value.confirmPassword
      ) {
        throw new Error("New passwords do not match");
      }
      await updatePassword();
    }

    alert("Changes saved successfully");
    emit("close");
  } catch (error) {
    alert(error.message);
  }
};

const updateProfile = async () => {
  try {
    const formDataToSend = new FormData();
    formDataToSend.append("fullName", formData.value.fullName);
    formDataToSend.append("email", formData.value.email);
    formDataToSend.append("contactNo", formData.value.phoneNumber);

    if (newProfileImage.value) {
      formDataToSend.append("profilePicture", newProfileImage.value);
    }

    const response = await fetch("http://localhost:3000/api/user/update", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token.value}`,
      },
      body: formDataToSend,
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Failed to update profile");
    }

    const result = await response.json();

    if (result.success) {
      localStorage.setItem("user", JSON.stringify(result.user));
      emit("success", "Profile updated successfully");
      emit("close");
    }
  } catch (error) {
    console.error("Error updating profile:", error);
    alert(error.message || "Failed to update profile");
  }
};

const updatePassword = async () => {
  const response = await fetch(
    "http://localhost:3000/api/user/change-password",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: token.value,
      },
      body: JSON.stringify({
        currentPassword: passwordData.value.currentPassword,
        newPassword: passwordData.value.newPassword,
      }),
    }
  );

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || "Failed to change password");
  }
};

// New refs for OTP handling
const showOtpModal = ref(false);
const otpCode = ref("");
const otpMessage = ref("");
const verificationMode = ref(""); // 'email' or 'phone'
const generatedOtp = ref("");

// Email verification function
const sendEmailVerification = async () => {
  try {
    generatedOtp.value = Math.floor(100000 + Math.random() * 900000).toString();
    verificationMode.value = "email";

    await sendVerificationEmail(
      formData.value.email,
      generatedOtp.value,
      formData.value.fullName
    );

    showOtpModal.value = true;
    otpMessage.value = "Please check your email for the verification code";
  } catch (error) {
    alert("Failed to send verification email: " + error.message);
  }
};

// Phone verification function
const sendPhoneVerification = async () => {
  try {
    // Generate a 6-digit OTP
    generatedOtp.value = Math.floor(100000 + Math.random() * 900000).toString();
    verificationMode.value = "phone";

    // Send SMS using Abstract API
    const response = await axios.post(
      "https://sms-verify.p.rapidapi.com/verify",
      {
        phone_number: formData.value.phoneNumber,
        code: generatedOtp.value,
      },
      {
        headers: {
          "X-RapidAPI-Key": "YOUR_RAPID_API_KEY", // Replace with your RapidAPI key
          "X-RapidAPI-Host": "sms-verify.p.rapidapi.com",
        },
      }
    );

    if (response.data.status === "success") {
      showOtpModal.value = true;
      otpMessage.value = "Please check your phone for the verification code";
    } else {
      throw new Error("Failed to send verification code");
    }
  } catch (error) {
    alert("Failed to send verification SMS: " + error.message);
  }
};

// Verify OTP
const verifyOtp = async () => {
  try {
    if (otpCode.value === generatedOtp.value) {
      // Update verification status based on mode
      if (verificationMode.value === "email") {
        formData.value.emailVerified = true;
      } else {
        formData.value.phoneVerified = true;
      }

      // Update verification status in backend
      await updateVerificationStatus(verificationMode.value);

      closeOtpModal();
      alert(
        `${
          verificationMode.value.charAt(0).toUpperCase() +
          verificationMode.value.slice(1)
        } verified successfully!`
      );
    } else {
      alert("Invalid verification code. Please try again.");
    }
  } catch (error) {
    console.error("Verification failed:", error);
    alert("Verification failed. Please try again.");
  }
};

// Update verification status in backend
const updateVerificationStatus = async (type) => {
  try {
    const response = await fetch(
      `http://localhost:3000/api/users/verify/${type}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.value}`,
        },
        body: JSON.stringify({
          userId: user.value.id,
          [`${type}Verified`]: true,
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`Failed to update ${type} verification status`);
    }

    // Update local storage
    const userData = JSON.parse(localStorage.getItem("user") || "{}");
    userData[`${type}Verified`] = true;
    localStorage.setItem("user", JSON.stringify(userData));
  } catch (error) {
    console.error(`Error updating ${type} verification:`, error);
    throw error;
  }
};

const closeOtpModal = () => {
  showOtpModal.value = false;
  otpCode.value = "";
  otpMessage.value = "";
  verificationMode.value = "";
};
</script>

<style scoped>
.profile-settings-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 2rem;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
  transition: background-color 0.3s, color 0.3s;
}

/* Dark Mode Styles */
.modal-content.dark-mode {
  background: #1a1a1a;
  color: #ffffff;
  border: 1px solid #404040;
}

.modal-content.dark-mode h2,
.modal-content.dark-mode h3 {
  color: #ffffff;
}

.modal-content.dark-mode .form-group label {
  color: #ffffff;
}

.modal-content.dark-mode input {
  background: #2d2d2d;
  border: 1px solid #404040;
  color: #ffffff;
}

.modal-content.dark-mode input::placeholder {
  color: #a0a0a0;
}

.modal-content.dark-mode .verification-status {
  color: #ff6b6b;
}

.modal-content.dark-mode .password-form {
  border-top: 1px solid #404040;
}

.modal-content.dark-mode .change-picture-btn {
  background-color: #2196f3;
  color: #ffffff;
}

.modal-content.dark-mode .save-btn {
  background-color: #4caf50;
  color: #ffffff;
}

.modal-content.dark-mode .cancel-btn {
  background-color: #f44336;
  color: #ffffff;
}

/* Add styles for text elements to ensure visibility */
.modal-content.dark-mode p,
.modal-content.dark-mode span:not(.verification-status) {
  color: #ffffff;
}

/* Improve input contrast in dark mode */
.modal-content.dark-mode input:focus {
  border-color: #2196f3;
  outline: none;
  box-shadow: 0 0 0 2px rgba(33, 150, 243, 0.3);
}

/* Improve button hover states in dark mode */
.modal-content.dark-mode .change-picture-btn:hover {
  background-color: #1976d2;
}

.modal-content.dark-mode .save-btn:hover {
  background-color: #45a049;
}

.modal-content.dark-mode .cancel-btn:hover {
  background-color: #d32f2f;
}

/* Add transition for smooth mode switching */
.modal-content {
  transition: background-color 0.3s, color 0.3s;
}

input {
  transition: background-color 0.3s, border-color 0.3s, color 0.3s;
}

/* Regular Styles */
.settings-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.profile-picture-section {
  text-align: center;
}

.profile-picture-container {
  width: 120px;
  height: 120px;
  margin: 0 auto 1rem;
}

.profile-picture-container img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
}

.form-group {
  margin-bottom: 1.5rem;
  position: relative;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
}

.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.95rem;
}

.verification-status {
  position: absolute;
  right: 0;
  top: 0;
  color: #ff4444;
  font-size: 0.8rem;
}

.password-form {
  margin-top: 2rem;
  padding-top: 2rem;
  border-top: 1px solid #ddd;
}

.password-form h3 {
  margin-bottom: 1.5rem;
  font-size: 1.2rem;
}

.button-group {
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
}

.save-btn,
.cancel-btn {
  flex: 1;
  padding: 0.75rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 1rem;
  transition: all 0.3s ease;
}

.save-btn {
  background-color: #4caf50;
  color: white;
}

.save-btn:hover {
  background-color: #45a049;
}

.cancel-btn {
  background-color: #f44336;
  color: white;
}

.cancel-btn:hover {
  background-color: #da190b;
}

.change-picture-btn {
  background-color: #2196f3;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.95rem;
  transition: background-color 0.3s;
}

.change-picture-btn:hover {
  background-color: #1976d2;
}

@media (max-width: 600px) {
  .modal-content {
    width: 95%;
    padding: 1.5rem;
  }

  .button-group {
    flex-direction: column;
  }

  .save-btn,
  .cancel-btn {
    width: 100%;
  }
}

.verification-status {
  font-size: 0.8rem;
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  margin-left: 0.5rem;
  color: #ff6b6b;
}

.verification-status.verified {
  color: #4caf50;
}

.form-group {
  position: relative;
  margin-bottom: 1.5rem;
}

/* Update input styles to accommodate verification status */
.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
  margin-top: 0.5rem;
}

.otp-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.otp-content {
  background: white;
  padding: 2rem;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
  transition: background-color 0.3s, color 0.3s;
}

/* Dark Mode Styles */
.otp-content.dark-mode {
  background: #1a1a1a;
  color: #ffffff;
  border: 1px solid #404040;
}

.otp-content.dark-mode h2,
.otp-content.dark-mode h3 {
  color: #ffffff;
}

.otp-content.dark-mode .form-group label {
  color: #ffffff;
}

.otp-content.dark-mode input {
  background: #2d2d2d;
  border: 1px solid #404040;
  color: #ffffff;
}

.otp-content.dark-mode input::placeholder {
  color: #a0a0a0;
}

.otp-content.dark-mode .verification-status {
  color: #ff6b6b;
}

.otp-content.dark-mode .password-form {
  border-top: 1px solid #404040;
}

.otp-content.dark-mode .change-picture-btn {
  background-color: #2196f3;
  color: #ffffff;
}

.otp-content.dark-mode .save-btn {
  background-color: #4caf50;
  color: #ffffff;
}

.otp-content.dark-mode .cancel-btn {
  background-color: #f44336;
  color: #ffffff;
}

/* Add styles for text elements to ensure visibility */
.otp-content.dark-mode p,
.otp-content.dark-mode span:not(.verification-status) {
  color: #ffffff;
}

/* Improve input contrast in dark mode */
.otp-content.dark-mode input:focus {
  border-color: #2196f3;
  outline: none;
  box-shadow: 0 0 0 2px rgba(33, 150, 243, 0.3);
}

/* Improve button hover states in dark mode */
.otp-content.dark-mode .change-picture-btn:hover {
  background-color: #1976d2;
}

.otp-content.dark-mode .save-btn:hover {
  background-color: #45a049;
}

.otp-content.dark-mode .cancel-btn:hover {
  background-color: #d32f2f;
}

/* Add transition for smooth mode switching */
.otp-content {
  transition: background-color 0.3s, color 0.3s;
}

input {
  transition: background-color 0.3s, border-color 0.3s, color 0.3s;
}

/* Regular Styles */
.settings-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.profile-picture-section {
  text-align: center;
}

.profile-picture-container {
  width: 120px;
  height: 120px;
  margin: 0 auto 1rem;
}

.profile-picture-container img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
}

.form-group {
  margin-bottom: 1.5rem;
  position: relative;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
}

.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.95rem;
}

.verification-status {
  position: absolute;
  right: 0;
  top: 0;
  color: #ff4444;
  font-size: 0.8rem;
}

.password-form {
  margin-top: 2rem;
  padding-top: 2rem;
  border-top: 1px solid #ddd;
}

.password-form h3 {
  margin-bottom: 1.5rem;
  font-size: 1.2rem;
}

.button-group {
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
}

.save-btn,
.cancel-btn {
  flex: 1;
  padding: 0.75rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 1rem;
  transition: all 0.3s ease;
}

.save-btn {
  background-color: #4caf50;
  color: white;
}

.save-btn:hover {
  background-color: #45a049;
}

.cancel-btn {
  background-color: #f44336;
  color: white;
}

.cancel-btn:hover {
  background-color: #da190b;
}

.change-picture-btn {
  background-color: #2196f3;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.95rem;
  transition: background-color 0.3s;
}

.change-picture-btn:hover {
  background-color: #1976d2;
}

@media (max-width: 600px) {
  .otp-content {
    width: 95%;
    padding: 1.5rem;
  }

  .button-group {
    flex-direction: column;
  }

  .save-btn,
  .cancel-btn {
    width: 100%;
  }
}

.verification-status {
  font-size: 0.8rem;
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  margin-left: 0.5rem;
  color: #ff6b6b;
}

.verification-status.verified {
  color: #4caf50;
}

.form-group {
  position: relative;
  margin-bottom: 1.5rem;
}

/* Update input styles to accommodate verification status */
.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
  margin-top: 0.5rem;
}

.phone-input-container {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  width: 100%;
}

.country-code {
  background: #f5f5f5;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
  color: #333;
  min-width: 60px;
  text-align: center;
}

.dark-mode .country-code {
  background: #2d2d2d;
  border-color: #404040;
  color: white;
}

.phone-input-container input {
  flex: 1;
}

.email-input-container,
.phone-input-container {
  position: relative;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.verify-btn {
  white-space: nowrap;
  padding: 0.5rem 1rem;
  background: #2196f3;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.85rem;
  transition: background-color 0.3s;
}

.verify-btn:hover {
  background: #1976d2;
}

.verification-status {
  font-size: 0.8rem;
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  white-space: nowrap;
}

.verification-status.verified {
  color: #4caf50;
}

.verification-status:not(.verified) {
  color: #ff6b6b;
}
</style>
