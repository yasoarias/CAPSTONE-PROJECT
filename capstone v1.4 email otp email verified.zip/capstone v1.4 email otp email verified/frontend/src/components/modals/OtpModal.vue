<template>
  <div class="otp-modal" @click="$emit('close')">
    <div class="otp-content" @click.stop>
      <h2>Verify {{ verificationMode === "email" ? "Email" : "Phone" }}</h2>
      <p class="otp-message">{{ otpMessage }}</p>
      <div class="otp-input-container">
        <input
          type="text"
          v-model="code"
          placeholder="Enter verification code"
          maxlength="6"
          class="otp-input"
        />
      </div>
      <div class="otp-buttons">
        <button @click="$emit('verify', code)" class="verify-otp-btn">
          Verify
        </button>
        <button @click="$emit('close')" class="cancel-otp-btn">Cancel</button>
      </div>
    </div>
  </div>
</template>
