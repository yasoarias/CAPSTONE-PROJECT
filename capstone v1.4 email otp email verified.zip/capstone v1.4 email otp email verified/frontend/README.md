# Vue 3 + Vite

This template should help get you started developing with Vue 3 in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about IDE Support for Vue in the [Vue Docs Scaling up Guide](https://vuejs.org/guide/scaling-up/tooling.html#ide-support).

ADMIN CREDENTIALS
admin@gmail.com
admin123


INSTALLATION
npm create vite@latest
npm install (to install the dependencies)
npm run dev (to start the development server)     
npm run build (to build the production version)
npm install jsonwebtoken bcryptjs
npm install mysql2
npm install nodemon
npm install express
npm install cors
npm install dotenv
npm install jwt-decode
npm install axios
npm install vue-router
