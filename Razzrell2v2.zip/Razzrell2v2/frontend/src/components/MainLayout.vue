<nav class="nav-links">
  <router-link to="/" class="nav-link">Home</router-link>
  <router-link to="/packages" class="nav-link">Packages</router-link>
  <router-link to="/gallery" class="nav-link">Gallery</router-link>
  <router-link to="/contact" class="nav-link">Contact</router-link>
</nav> 